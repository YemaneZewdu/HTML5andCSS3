/*

JavaScript file for the sliding images

*/

var Index = 0;
slider();

function slider() {
    var i;
    var x = document.getElementsByClassName("Slides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    Index++;
    if (Index > x.length) {Index = 1}    
    x[Index-1].style.display = "block";  
    setTimeout(slider, 9000);    
}
