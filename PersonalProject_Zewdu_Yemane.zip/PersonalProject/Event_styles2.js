/*
  UDC ACM CLUB General Style Sheet
  Author: Yemane Zewdu
  Date: 10/28/2017
  File name: Event_styles2.js
*/

var time= new Date();
var clock= document.getElementById('clock');
var hexColor= document.getElementById('hex-color');

function hexClock()
{
	var time= new Date();
	var hours= (time.getHours() % 12);
	var minutes= time.getMinutes();
	var seconds = time.getSeconds();
	
	
	hours = (hours < 10) ? "0" + hours : hours;
	minutes = (minutes < 10) ? "0" + minutes : minutes;
	seconds = (seconds < 10) ? "0" + seconds : seconds;

	var clockStr = hours + ' : ' + minutes + ' . ' + seconds;
	var hexColorStr = '#' + hours + minutes + seconds;
	
	clock.textContent = clockStr;
	hexColor.textContent= hexColorStr;
	
	document.body.style.backgroundColor = hexColorStr;
}
hexClock();
setInterval(hexClock,1000);


